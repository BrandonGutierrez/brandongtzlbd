use Proyecto

select * from asientos
select * from autobuses
select * from conductores
select * from pasajeros
select * from terminal
select * from vendedores

insert into asientos values (105,32, 'disponible')
insert into asientos values (106,32, 'disponible')
insert into asientos values (107,32, 'disponible')
insert into asientos values (108,32, 'disponible')
insert into asientos values (109,32, 'disponible')
insert into asientos values (110,32, 'disponible')
insert into asientos values (111,32, 'disponible')
insert into asientos values (112,32, 'disponible')
insert into asientos values (113,32, 'disponible')
insert into asientos values (114,32, 'disponible')
insert into asientos values (115,32, 'disponible')
insert into asientos values (116,32, 'disponible')

insert into autobuses values (100,10, 'SENDMTY', 32, 'disponible', 1)
insert into autobuses values (101,10, 'SENDMTYA', 32, 'disponible', 1)
insert into autobuses values (102,10, 'SENDMTYB', 32, 'disponible', 1)
insert into autobuses values (103,10, 'SENDMTYC', 32, 'disponible', 1)
insert into autobuses values (104,10, 'SENDMTYD', 32, 'disponible', 1)
insert into autobuses values (105,10, 'SENDMTYE', 32, 'disponible', 1)
insert into autobuses values (106,10, 'SENDMTYF', 32, 'disponible', 1)
insert into autobuses values (107,10, 'SENDMTYG', 32, 'disponible', 1)
insert into autobuses values (108,10, 'SENDMTYH', 32, 'disponible', 2)
insert into autobuses values (109,10, 'SENDMTYI', 32, 'disponible', 2)
insert into autobuses values (110,10, 'SENDMTYJ', 32, 'disponible', 2)
insert into autobuses values (111,10, 'SENDMTYK', 32, 'disponible', 2)
insert into autobuses values (112,10, 'SENDMTYM', 32, 'disponible', 2)

insert into conductores values (10,'JORDI BELMONTE AVILES', '118', 'Av.Juarez 166 Colonia El Paseo', '05:00', '08:00')
insert into conductores values (11,'ANDRES COTO CASANOVAS', '119', 'Jose Morelos 845 Colonia Aramberri', '05:00', '08:00')
insert into conductores values (12,'JORGE LOPEZ LECHUGA', '120', 'Pilon Kasas 226 Colonia El Laberinto', '05:00', '08:00')
insert into conductores values (13,'JOSE FRANCISCO REINOSO CUBERO', '121', '7 de Julio 445 Colonia Los Nogales', '05:00', '08:00')
insert into conductores values (14,'ANDRE PIERRE GIGNAC', '122', 'Av.Principal 566 Colonia Flores', '05:00', '08:00')
insert into conductores values (15,'MIGUEL ANGEL APARICIO RUBIO', '123', 'Maria Morelos 201 Colonia Casa Bella', '05:00', '08:00')
insert into conductores values (16,'SEBASTIAN CEPEDA OLIVER', '124', 'Maria Morelos 203 Colonia Casa Bella', '05:00', '08:00')
insert into conductores values (17,'HUGO MAYO CARNERO', '125', 'Gonzales Perez 119 Colonia Granjeros', '05:00', '08:00')
insert into conductores values (18,'SEBASTIAN BALLESTEROS NAVAJAS', '126', 'Epsilon 558 Colonia Santa Teresa', '05:00', '08:00')
insert into conductores values (19,'DOMINGO CARRERAS SOTELO', '127', 'Phobos 789 Colonia Cosmopolis', '05:00', '08:00')
insert into conductores values (20,'JOSE MANUEL SALVADO PICO', '128', 'Alvaro Obregon 103 Colonia Ricardo Solaris', '05:00', '08:00')
insert into conductores values (21,'PILAR ROS CARRILLO', '129', 'Av.Juarez 998 Colonia Del Valle', '05:00', '08:00')
insert into conductores values (22,'MARIA JESUS GRAS ARAMBURU', '130', 'Miguel Hidalgo 550 Colonia Independencia', '05:00', '08:00')

insert into terminal values (140, 'Terminal Aguascalientes','Aguascalientes')
insert into terminal values (2, 'Terminal Baja California','Aguascalientes')
insert into terminal values (3, 'Terminal Baja California Sur','Baja California Sur')
insert into terminal values (4, 'Terminal Campeche','Campeche')
insert into terminal values (5, 'Terminal Coahuila','Coahuila de Zaragoza')
insert into terminal values (6, 'Terminal Colima','Colima')
insert into terminal values (7, 'Terminal Chiapas','Chiapas')
insert into terminal values (8, 'Terminal Chihuahua','Chihuahua')
insert into terminal values (9, 'Terminal CDMX','Ciudad de Mexico')
insert into terminal values (10, 'Terminal Durango','Durango')
insert into terminal values (11, 'Terminal Guanajuato','Guanajuato')
insert into terminal values (12, 'Terminal Guerrero','Guerrero')
insert into terminal values (13, 'Terminal Hidalgo','Hidalgo')
insert into terminal values (14, 'Terminal Jalisco','Jalisco')
insert into terminal values (15, 'Terminal Mexico','Mexico')
insert into terminal values (16, 'Terminal Michoacan','Michoacan')
insert into terminal values (17, 'Terminal Morelos','Morelos')
insert into terminal values (18, 'Terminal Nayarit','Nayarit')
insert into terminal values (19, 'Terminal Nuevo Leon','Nuevo Leon')
insert into terminal values (20, 'Terminal Oaxaca','Oaxaca')
insert into terminal values (21, 'Terminal Puebla','Puebla')
insert into terminal values (22, 'Terminal Queretaro','Queretaro')
insert into terminal values (23, 'Terminal Quintana Roo','Quintana Roo')
insert into terminal values (24, 'Terminal San Luis Potosi','San Luis Potosi')
insert into terminal values (25, 'Terminal Sinaloa','Sinaloa')
insert into terminal values (26, 'Terminal Sonora','Sonora')
insert into terminal values (27, 'Terminal Tabasco','Tabasco')
insert into terminal values (28, 'Terminal Tamaulipas','Tamaulipas')
insert into terminal values (29, 'Terminal Tlaxcala','Tlaxcala')
insert into terminal values (30, 'Terminal Veracruz','Veracruz')
insert into terminal values (31, 'Terminal Yucatan','Yucatan')
insert into terminal values (32, 'Terminal Zacatecas','Zacatecas')

insert into pasajeros values(10,'ADRIAN GORDON GALLO',5195789)
insert into pasajeros values(11,'ANDRES MAYA DIAZ',5195887)
insert into pasajeros values(12,'ANDRES IGLESIAS VILLA',5195666)
insert into pasajeros values(13,'JOSE IGNACIO MARCHANTE CUARTERO',5195555)
insert into pasajeros values(14,'SAMUEL MATUTE GARCES',5195111)
insert into pasajeros values(15,'TOMAS ROMANO BERMUDEZ',5195222)
insert into pasajeros values(16,'JOSE FRANCISCO CUENCA COLLADO',5195333)
insert into pasajeros values(17,'ANDRES CALLE CASTEJON',5195444)
insert into pasajeros values(18,'JOSE LOIS BAQUERO',5195777)
insert into pasajeros values(19,'DAVID BLASCO FIDALGO',5195888)
insert into pasajeros values(20,'JUAN JOSE VIGIL GAZQUEZ',5195999)
insert into pasajeros values(21,'VICTOR MANUEL REGALADO EZQUERRA',5195101)
insert into pasajeros values(22,'OSCAR GARCIA TORRES',5195110)
insert into pasajeros values(23,'ANGELES PIQUERAS GUERRA',5195121)
insert into pasajeros values(24,'VICTORIA FALCON GEORGIEV',5195131)
insert into pasajeros values(25,'MARIA ELENA CODINA FRANCISCO',5195141)
insert into pasajeros values(26,'ANGELA BLANCA SALCEDO',5195151)
insert into pasajeros values(27,'CONSUELO SARABIA VELARDE',5195161)
insert into pasajeros values(28,'CONCEPCION ALFONSO EDO',5195171)
insert into pasajeros values(29,'ANTONIA FALCO MANZANO',5195181)

insert into vendedores values (12345, 'Terminal Aguascalientes', 'FRANCISCA BADIA VADILLO', 811789945 , 'Camino Sindique 555 Col Los Rogas', '07/09/2006', 1)
insert into vendedores values (12346, 'Terminal Baja California', 'LORENA CHAVEZ SAURA', 811892351 , 'Alameda 515 Col Los Gonzales', '11/01/2012', 1)
insert into vendedores values (12347, 'Terminal Baja California Sur', 'JUANA BARCO ORTS', 812648971 , 'Alamos 700 Col Zapatero', '07/09/2015', 1)
insert into vendedores values (12348, 'Terminal Campeche', 'FRANCISCO JAVIER ESPARZA VEGAS', 812616146 , 'Paposotos 800 Col Artillero', '07/09/2004', 1)
insert into vendedores values (12349, 'Terminal Coahuila', 'MARTIN CARDENAS ROIG', 811982310 , 'Rata Sindique 805 Col Jucasito', '07/09/2007', 1)
insert into vendedores values (123410, 'Terminal Colima', 'HUGO TEJERO TORMO', 811215489 , 'Afganistan 809 Col Tepex', '07/09/2009', 1)
insert into vendedores values (123411, 'Terminal Chiapas', 'MOHAMED BARROSO MINGUEZ', 811025156 , 'Rartos 455 Col Tulipanes', '07/09/2009', 1)
insert into vendedores values (123412, 'Terminal Chihuahua', 'JOSE ANGEL DEL REY ROSALES', 811200120 , 'Prados 324 Col Santa Martha', '07/09/2016', 1)
insert into vendedores values (123413, 'Terminal CDMX', 'EVA MILLA FORTES', 811988456 , 'Batks 210 Col La Unidad', '07/09/2016', 1)
insert into vendedores values (123414, 'Terminal Durango', 'RAQUEL ALBERT FORNES', 811126542 , 'Ursupales 454 Col Especiales', '07/09/2014', 1)
insert into vendedores values (123415, 'Terminal Nuevo Leon', 'INES CERVERA PAYA', 812648912 , 'Lolas 422 Col Los Prados', '07/09/2013', 0)
insert into vendedores values (123416, 'Terminal Queretaro', 'ROCIO VALDEZ QUERO', 812648981 , 'Lagos 777 Col Los Ricos', '07/09/2011', 0)
insert into vendedores values (123417, 'Terminal Puebla', 'NOELIA PUCHE INIESTA', 811056412 , 'Serafin Gonzales 333 Col Los Pobres', '07/09/2011', 0)
insert into vendedores values (123418, 'Terminal Tamaulipas', 'JOAN FORTUNY LUGO', 818942103 , 'Perez Rios 245 Col Los Bellos Lados', '07/09/2007', 0)
insert into vendedores values (123419, 'Terminal Zacatecas', 'JOSEP VIEIRA LARIOS', 818974217 , 'Arturo Bravo 478 Col Karthon', '07/09/2006', 0)

update terminal set municipio = 'Baja California' where terminal_id=2
update terminal set terminal_id = 1 where terminal_id = 140
update vendedores set terminal = 'Terminal Yucatan' where vendedor_id=12348
update pasajeros set pasajero_nombre = 'CONCEPCION ALFONSO DOMINGUEZ' where pasajeros_id = 28 
update asientos set asientos_estado = 'Ocupado' where asientos_id = 111

delete from vendedores where vendedor_id = 123415
delete from vendedores where vendedor_domicilio = 'Lagos 777 Col Los Ricos'
delete from vendedores where vendedor_nombre = 'NOELIA PUCHE INIESTA'
delete from vendedores where vendedor_telefono = 818942103
delete from vendedores where vendedor_fecha_reg = '07/09/2006'